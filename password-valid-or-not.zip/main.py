import string

def passw(a):
    x=string.ascii_letters
    y=string.digits
    z=8
    lett=any (let in x for let in a)
    dig=(num in y for num in a )
    if (lett and dig and len(a)>z):
        print("password valid")
    else:
        print("invalid ")
b=input("enter your password: ")
passw(b)